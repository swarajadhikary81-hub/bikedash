package com.bikedash.app

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** The big full-screen bike display on the BIKE phone. */
class DashboardActivity : Activity() {

    private val CYAN = Color.parseColor("#00E5FF")
    private val CARD = Color.parseColor("#1A2230")
    private val GREEN = Color.parseColor("#1DB954")
    private val RED = Color.parseColor("#E53935")
    private val DARK_BTN = Color.parseColor("#263042")

    private lateinit var clockTv: TextView
    private lateinit var statusTv: TextView
    private lateinit var batteryTv: TextView
    private lateinit var speedTv: TextView
    private lateinit var appTv: TextView
    private lateinit var titleTv: TextView
    private lateinit var textTv: TextView
    private lateinit var callBox: LinearLayout
    private lateinit var callLabel: TextView
    private lateinit var callName: TextView
    private lateinit var callNumber: TextView
    private lateinit var answerBtn: Button
    private lateinit var rejectBtn: Button
    private lateinit var voiceBtn: Button

    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences(BikeLink.PREFS, MODE_PRIVATE) }
    private var lm: LocationManager? = null
    private var bikeBattery = -1

    private val locListener = LocationListener { loc ->
        val kmh = if (loc.hasSpeed()) (loc.speed * 3.6f).roundToInt() else 0
        speedTv.text = kmh.toString()
    }

    private val clockTick = object : Runnable {
        override fun run() {
            clockTv.text = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            handler.postDelayed(this, 1000)
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (level >= 0 && scale > 0) bikeBattery = level * 100 / scale
            updateBattery()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        setContentView(buildUi())
    }

    // ---------- UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun tv(size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun btn(label: String, bg: Int, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 18f
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(bg); cornerRadius = dp(16).toFloat() }
        setOnClickListener { onClick() }
    }

    private fun buildUi(): View {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }

        // top bar: clock | connection | batteries
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        clockTv = tv(26f, Color.WHITE, true)
        statusTv = tv(15f, Color.LTGRAY).apply { gravity = Gravity.CENTER }
        batteryTv = tv(15f, Color.LTGRAY).apply { gravity = Gravity.END }
        top.addView(clockTv, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        top.addView(statusTv, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1.4f))
        top.addView(batteryTv, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        main.addView(top, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        // speedometer
        val speedBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        speedTv = tv(150f, Color.WHITE, true).apply {
            text = "0"
            gravity = Gravity.CENTER
            includeFontPadding = false
            setAutoSizeTextTypeUniformWithConfiguration(40, 220, 4, TypedValue.COMPLEX_UNIT_SP)
        }
        speedBox.addView(speedTv, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        speedBox.addView(tv(22f, CYAN, true).apply { text = "km/h"; gravity = Gravity.CENTER })
        main.addView(speedBox, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        // last message card
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(14))
            background = GradientDrawable().apply { setColor(CARD); cornerRadius = dp(18).toFloat() }
        }
        appTv = tv(15f, CYAN, true).apply { text = "No messages yet" }
        titleTv = tv(24f, Color.WHITE, true).apply { maxLines = 1 }
        textTv = tv(20f, Color.parseColor("#CFD8DC")).apply { maxLines = 3 }
        card.addView(appTv); card.addView(titleTv); card.addView(textTv)
        main.addView(card, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
            topMargin = dp(8); bottomMargin = dp(12)
        })

        // bottom buttons
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        voiceBtn = btn("", DARK_BTN) { toggleVoice() }
        val buttons = listOf(
            btn("🧭 Maps", DARK_BTN) { openMaps() },
            voiceBtn,
            btn("🗑 Clear", DARK_BTN) { BikeLink.lastMsg = null; showMsg(null) },
            btn("⏻ Stop", DARK_BTN) { stopDashboard() }
        )
        buttons.forEachIndexed { i, b ->
            row.addView(b, LinearLayout.LayoutParams(0, dp(64), 1f).apply {
                if (i > 0) marginStart = dp(8)
            })
        }
        main.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        root.addView(main, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        // incoming call overlay
        callBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#F20B1220"))
            setPadding(dp(24), dp(24), dp(24), dp(24))
            visibility = View.GONE
            isClickable = true
        }
        callLabel = tv(22f, CYAN, true).apply { gravity = Gravity.CENTER }
        callName = tv(46f, Color.WHITE, true).apply { gravity = Gravity.CENTER; maxLines = 2 }
        callNumber = tv(22f, Color.LTGRAY).apply { gravity = Gravity.CENTER }
        callBox.addView(callLabel)
        callBox.addView(callName, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) })
        callBox.addView(callNumber)
        val callRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        answerBtn = btn("✅ Answer", GREEN) { DashboardService.instance?.sendCommand("answer") }
        rejectBtn = btn("❌ Reject", RED) {
            DashboardService.instance?.sendCommand("reject")
            BikeLink.lastCall = null
            callBox.visibility = View.GONE
        }
        callRow.addView(answerBtn, LinearLayout.LayoutParams(0, dp(96), 1f))
        callRow.addView(rejectBtn, LinearLayout.LayoutParams(0, dp(96), 1f).apply { marginStart = dp(16) })
        callBox.addView(callRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(36) })
        root.addView(callBox, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        updateVoiceBtn()
        return root
    }

    // ---------- lifecycle ----------

    override fun onResume() {
        super.onResume()
        BikeLink.listener = { onEvent(it) }
        BikeLink.statusListener = { c, t -> setStatus(c, t) }
        setStatus(BikeLink.connected, BikeLink.statusText)
        showMsg(BikeLink.lastMsg)
        showCall(BikeLink.lastCall)
        handler.post(clockTick)
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        startGps()
        hideSystemBars()
    }

    override fun onPause() {
        super.onPause()
        BikeLink.listener = null
        BikeLink.statusListener = null
        handler.removeCallbacks(clockTick)
        try { unregisterReceiver(batteryReceiver) } catch (e: Exception) { }
        try { lm?.removeUpdates(locListener) } catch (e: Exception) { }
    }

    // ---------- events ----------

    private fun onEvent(o: JSONObject) {
        when (o.optString("t")) {
            "msg" -> showMsg(o)
            "call" -> showCall(o)
            "bat" -> updateBattery()
        }
    }

    private fun showMsg(o: JSONObject?) {
        if (o == null) {
            appTv.text = "No messages yet"; titleTv.text = ""; textTv.text = ""
            return
        }
        appTv.text = o.optString("app")
        titleTv.text = o.optString("title")
        textTv.text = o.optString("text")
    }

    private fun showCall(o: JSONObject?) {
        if (o == null || o.optString("state") == "end") {
            callBox.visibility = View.GONE
            return
        }
        val name = o.optString("name")
        val num = o.optString("number")
        callBox.visibility = View.VISIBLE
        callName.text = name.ifBlank { num.ifBlank { "Unknown caller" } }
        callNumber.text = if (name.isNotBlank()) num else ""
        if (o.optString("state") == "ringing") {
            callLabel.text = "📞 Incoming call"
            answerBtn.visibility = View.VISIBLE
            rejectBtn.text = "❌ Reject"
        } else {
            callLabel.text = "On call"
            if (name.isBlank() && num.isBlank()) callName.text = "Call in progress"
            answerBtn.visibility = View.GONE
            rejectBtn.text = "❌ End call"
        }
    }

    private fun setStatus(connected: Boolean, text: String) {
        statusTv.text = (if (connected) "🟢 " else "🔴 ") + text
    }

    private fun updateBattery() {
        val b = if (bikeBattery >= 0) "$bikeBattery%" else "--"
        val m = if (BikeLink.mainBattery >= 0) "${BikeLink.mainBattery}%" else "--"
        batteryTv.text = "🏍 $b   📱 $m"
    }

    // ---------- actions ----------

    private fun startGps() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            speedTv.text = "--"
            return
        }
        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        try {
            lm?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locListener, Looper.getMainLooper())
        } catch (e: Exception) { }
    }

    private fun openMaps() {
        val i = packageManager.getLaunchIntentForPackage("com.google.android.apps.maps")
            ?: Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="))
        try { startActivity(i) } catch (e: Exception) { }
    }

    private fun toggleVoice() {
        prefs.edit().putBoolean("voice", !prefs.getBoolean("voice", true)).apply()
        updateVoiceBtn()
    }

    private fun updateVoiceBtn() {
        voiceBtn.text = if (prefs.getBoolean("voice", true)) "🔊 Voice" else "🔇 Muted"
    }

    private fun stopDashboard() {
        prefs.edit().remove("mode").apply()
        startService(Intent(this, DashboardService::class.java).setAction(DashboardService.ACTION_STOP))
        finish()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }
}
