package com.bikedash.app

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONObject

/** MAIN phone: reads new notifications (WhatsApp, SMS, missed calls…) and forwards them. */
class NotifListener : NotificationListenerService() {

    private var lastKey = ""
    private var lastTime = 0L

    // Apps whose notifications are never forwarded. Add package names here to mute them.
    private val blocked = setOf(
        "android", "com.android.systemui", "com.android.vending", "com.google.android.gms"
    )

    private val skipCategories = setOf(
        Notification.CATEGORY_CALL, Notification.CATEGORY_PROGRESS, Notification.CATEGORY_TRANSPORT,
        Notification.CATEGORY_SERVICE, Notification.CATEGORY_SYSTEM, Notification.CATEGORY_NAVIGATION
    )

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val svc = SenderService.instance ?: return
        val pkg = sbn.packageName
        if (pkg == packageName || pkg in blocked) return
        if (sbn.isOngoing) return
        val n = sbn.notification
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val cat: String? = n.category
        if (cat != null && skipCategories.contains(cat)) return

        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))
            ?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return

        val key = pkg + title + text
        val now = System.currentTimeMillis()
        if (key == lastKey && now - lastTime < 5000) return
        lastKey = key
        lastTime = now

        svc.send(
            JSONObject().put("t", "msg").put("app", appName(pkg))
                .put("title", title).put("text", text.take(400))
        )
    }

    private fun appName(pkg: String): String = when (pkg) {
        "com.whatsapp" -> "WhatsApp"
        "com.whatsapp.w4b" -> "WhatsApp Business"
        "com.google.android.apps.messaging" -> "Messages"
        "org.telegram.messenger" -> "Telegram"
        "com.instagram.android" -> "Instagram"
        else -> try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() }
        }
    }
}
