package com.bikedash.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restarts the sender / dashboard automatically after the phone reboots. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val p = ctx.getSharedPreferences(BikeLink.PREFS, Context.MODE_PRIVATE)
        try {
            when (p.getString("mode", null)) {
                "sender" -> if (p.getString("device", null) != null)
                    ctx.startForegroundService(Intent(ctx, SenderService::class.java))
                "dash" -> ctx.startForegroundService(Intent(ctx, DashboardService::class.java))
            }
        } catch (e: Exception) { }
    }
}
