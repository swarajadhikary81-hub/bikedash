package com.bikedash.app

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.telecom.TelecomManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.concurrent.Executors

/** Runs on the MAIN phone. Keeps a Bluetooth link to the bike phone and forwards alerts. */
class SenderService : Service() {

    companion object {
        @Volatile var instance: SenderService? = null
        const val ACTION_STOP = "com.bikedash.app.STOP_SENDER"
        private const val CH = "sender"
        private const val NID = 11
    }

    @Volatile private var running = false
    @Volatile private var out: OutputStream? = null
    @Volatile private var socket: BluetoothSocket? = null
    private val writer = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private val nm by lazy { getSystemService(NotificationManager::class.java) }
    private val prefs by lazy { getSharedPreferences(BikeLink.PREFS, MODE_PRIVATE) }

    private val batteryTick = object : Runnable {
        override fun run() {
            sendBattery()
            handler.postDelayed(this, 60_000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        nm.createNotificationChannel(NotificationChannel(CH, "Bike link", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            running = false
            closeSocket()
            handler.removeCallbacksAndMessages(null)
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        ServiceCompat.startForeground(
            this, NID, notif("Starting…"),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE else 0
        )
        if (!running) {
            running = true
            Thread { connectLoop() }.start()
            handler.postDelayed(batteryTick, 60_000)
        }
        return START_STICKY
    }

    private fun status(c: Boolean, text: String) {
        BikeLink.setStatus(c, text)
        try { nm.notify(NID, notif(text)) } catch (e: Exception) { }
    }

    @SuppressLint("MissingPermission")
    private fun connectLoop() {
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        while (running) {
            val addr = prefs.getString("device", null)
            if (addr == null) { status(false, "No bike phone selected"); nap(3000); continue }
            if (adapter == null || !adapter.isEnabled) { status(false, "Turn ON Bluetooth"); nap(3000); continue }
            try {
                val dev = adapter.getRemoteDevice(addr)
                status(false, "Connecting to ${dev.name ?: "bike phone"}…")
                val s = dev.createRfcommSocketToServiceRecord(BikeLink.UUID_SPP)
                s.connect()
                socket = s
                out = s.outputStream
                status(true, "Connected to ${dev.name ?: "bike phone"}")
                sendBattery()
                val reader = BufferedReader(InputStreamReader(s.inputStream))
                while (running) {
                    val line = reader.readLine() ?: break
                    handleCommand(line)
                }
            } catch (e: Exception) {
            } finally {
                closeSocket()
            }
            if (running) {
                status(false, "Bike phone not reachable – retrying…")
                nap(4000)
            }
        }
    }

    fun send(o: JSONObject) {
        val line = o.toString() + "\n"
        writer.execute {
            try {
                out?.let { it.write(line.toByteArray()); it.flush() }
            } catch (e: Exception) {
                closeSocket()
            }
        }
    }

    private fun sendBattery() {
        val bm = getSystemService(BatteryManager::class.java)
        val lvl = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        send(JSONObject().put("t", "bat").put("level", lvl))
    }

    @Suppress("DEPRECATION")
    @SuppressLint("MissingPermission")
    private fun handleCommand(line: String) {
        val o = try { JSONObject(line) } catch (e: Exception) { return }
        if (o.optString("t") != "cmd") return
        val tm = getSystemService(TelecomManager::class.java)
        try {
            when (o.optString("c")) {
                "answer" -> tm.acceptRingingCall()
                "reject" -> if (Build.VERSION.SDK_INT >= 28) tm.endCall()
            }
        } catch (e: Exception) { }
    }

    private fun notif(text: String) = NotificationCompat.Builder(this, CH)
        .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
        .setContentTitle("BikeDash – main phone")
        .setContentText(text)
        .setOngoing(true)
        .setContentIntent(
            PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        )
        .build()

    private fun closeSocket() {
        try { socket?.close() } catch (e: Exception) { }
        socket = null
        out = null
    }

    private fun nap(ms: Long) {
        try { Thread.sleep(ms) } catch (e: InterruptedException) { }
    }

    override fun onDestroy() {
        running = false
        closeSocket()
        handler.removeCallbacksAndMessages(null)
        writer.shutdownNow()
        instance = null
        BikeLink.setStatus(false, "Sender stopped")
        super.onDestroy()
    }
}
