package com.bikedash.app

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.Locale
import java.util.concurrent.Executors

/** Runs on the BIKE phone. Waits for the main phone over Bluetooth and shows alerts. */
class DashboardService : Service(), TextToSpeech.OnInitListener {

    companion object {
        @Volatile var instance: DashboardService? = null
        const val ACTION_ANSWER = "com.bikedash.app.ANSWER"
        const val ACTION_REJECT = "com.bikedash.app.REJECT"
        const val ACTION_STOP = "com.bikedash.app.STOP_DASH"
        private const val CH_STATUS = "dash_status"
        private const val CH_ALERT = "dash_alert"
        private const val CH_CALL = "dash_call"
        private const val NID_STATUS = 1
        private const val NID_CALL = 2
    }

    @Volatile private var running = false
    @Volatile private var server: BluetoothServerSocket? = null
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var out: OutputStream? = null
    private val writer = Executors.newSingleThreadExecutor()
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var msgNid = 100
    private var lastSpokenCaller = ""
    private val nm by lazy { getSystemService(NotificationManager::class.java) }
    private val prefs by lazy { getSharedPreferences(BikeLink.PREFS, MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        nm.createNotificationChannel(NotificationChannel(CH_STATUS, "Dashboard status", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Messages from main phone", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_CALL, "Calls from main phone", NotificationManager.IMPORTANCE_HIGH))
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            val r = tts?.setLanguage(Locale.getDefault())
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts?.setLanguage(Locale.ENGLISH)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ANSWER -> { sendCommand("answer"); return START_STICKY }
            ACTION_REJECT -> { sendCommand("reject"); nm.cancel(NID_CALL); return START_STICKY }
            ACTION_STOP -> { stopEverything(); return START_NOT_STICKY }
        }
        ServiceCompat.startForeground(
            this, NID_STATUS, statusNotif(BikeLink.statusText),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE else 0
        )
        if (!running) {
            running = true
            Thread { serverLoop() }.start()
        }
        return START_STICKY
    }

    private fun status(c: Boolean, text: String) {
        BikeLink.setStatus(c, text)
        try { nm.notify(NID_STATUS, statusNotif(text)) } catch (e: Exception) { }
    }

    @SuppressLint("MissingPermission")
    private fun serverLoop() {
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        while (running) {
            try {
                if (adapter == null || !adapter.isEnabled) {
                    status(false, "Turn ON Bluetooth")
                    nap(3000)
                    continue
                }
                if (server == null) {
                    server = adapter.listenUsingRfcommWithServiceRecord(BikeLink.NAME, BikeLink.UUID_SPP)
                }
                status(false, "Waiting for main phone…")
                val s = server!!.accept()
                socket = s
                out = s.outputStream
                val remoteName: String? = try { s.remoteDevice?.name } catch (e: Exception) { null }
                val name = remoteName ?: "main phone"
                status(true, "Connected: $name")
                val reader = BufferedReader(InputStreamReader(s.inputStream))
                while (running) {
                    val line = reader.readLine() ?: break
                    handle(line)
                }
            } catch (e: Exception) {
                try { server?.close() } catch (e: Exception) { }
                server = null
                if (running) nap(2000)
            } finally {
                try { socket?.close() } catch (e: Exception) { }
                socket = null
                out = null
            }
            if (running) {
                // clear any stuck call screen after a disconnect
                val end = JSONObject().put("t", "call").put("state", "end")
                BikeLink.lastCall = null
                nm.cancel(NID_CALL)
                BikeLink.emit(end)
                status(false, "Main phone disconnected – waiting…")
            }
        }
    }

    private fun handle(line: String) {
        val o = try { JSONObject(line) } catch (e: Exception) { return }
        when (o.optString("t")) {
            "msg" -> { BikeLink.lastMsg = o; showMessage(o) }
            "call" -> { BikeLink.lastCall = if (o.optString("state") == "end") null else o; showCall(o) }
            "bat" -> BikeLink.mainBattery = o.optInt("level", -1)
        }
        BikeLink.emit(o)
    }

    private fun showMessage(o: JSONObject) {
        val app = o.optString("app")
        val title = o.optString("title")
        val text = o.optString("text")
        val n = NotificationCompat.Builder(this, CH_ALERT)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(if (title.isBlank()) app else "$title · $app")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setTimeoutAfter(20_000)
            .setContentIntent(openDash())
            .build()
        try { nm.notify(msgNid++, n) } catch (e: Exception) { }
        if (msgNid > 130) msgNid = 100
        speak("$app. $title. ${text.take(120)}")
    }

    private fun showCall(o: JSONObject) {
        val state = o.optString("state")
        val name = o.optString("name")
        val num = o.optString("number")
        val who = name.ifBlank { num.ifBlank { "Unknown caller" } }
        try {
            when (state) {
                "ringing" -> {
                    val n = NotificationCompat.Builder(this, CH_CALL)
                        .setSmallIcon(android.R.drawable.sym_call_incoming)
                        .setContentTitle("📞 $who")
                        .setContentText(if (name.isNotBlank()) num else "Incoming call")
                        .setPriority(NotificationCompat.PRIORITY_MAX)
                        .setCategory(NotificationCompat.CATEGORY_CALL)
                        .setOngoing(true)
                        .setContentIntent(openDash())
                        .addAction(0, "✅ Answer", svcIntent(ACTION_ANSWER, 1))
                        .addAction(0, "❌ Reject", svcIntent(ACTION_REJECT, 2))
                        .build()
                    nm.notify(NID_CALL, n)
                    if (who != lastSpokenCaller) {
                        lastSpokenCaller = who
                        speak("Call from $who")
                    }
                }
                "active" -> {
                    val label = if (name.isNotBlank() || num.isNotBlank()) who else "a call"
                    val n = NotificationCompat.Builder(this, CH_STATUS)
                        .setSmallIcon(android.R.drawable.sym_action_call)
                        .setContentTitle("On call · $label")
                        .setOngoing(true)
                        .setContentIntent(openDash())
                        .addAction(0, "❌ End call", svcIntent(ACTION_REJECT, 2))
                        .build()
                    nm.notify(NID_CALL, n)
                }
                else -> {
                    nm.cancel(NID_CALL)
                    lastSpokenCaller = ""
                }
            }
        } catch (e: Exception) { }
    }

    fun sendCommand(c: String) {
        val line = JSONObject().put("t", "cmd").put("c", c).toString() + "\n"
        writer.execute {
            try {
                out?.let { it.write(line.toByteArray()); it.flush() }
            } catch (e: Exception) { }
        }
    }

    private fun speak(text: String) {
        if (!prefs.getBoolean("voice", true) || !ttsReady) return
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "bd" + System.nanoTime())
    }

    private fun openDash(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, DashboardActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun svcIntent(action: String, req: Int): PendingIntent = PendingIntent.getService(
        this, req,
        Intent(this, DashboardService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun statusNotif(text: String) = NotificationCompat.Builder(this, CH_STATUS)
        .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
        .setContentTitle("BikeDash dashboard")
        .setContentText(text)
        .setOngoing(true)
        .setContentIntent(openDash())
        .build()

    private fun nap(ms: Long) {
        try { Thread.sleep(ms) } catch (e: InterruptedException) { }
    }

    private fun closeAll() {
        try { socket?.close() } catch (e: Exception) { }
        try { server?.close() } catch (e: Exception) { }
        socket = null
        server = null
        out = null
    }

    private fun stopEverything() {
        running = false
        closeAll()
        nm.cancel(NID_CALL)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        closeAll()
        writer.shutdownNow()
        tts?.shutdown()
        instance = null
        BikeLink.setStatus(false, "Dashboard stopped")
        super.onDestroy()
    }
}
