package com.bikedash.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject
import kotlin.math.roundToInt

/** Setup screen: choose whether this phone is the BIKE phone or the MAIN phone. */
class MainActivity : Activity() {

    private val CYAN = Color.parseColor("#00E5FF")
    private val prefs by lazy { getSharedPreferences(BikeLink.PREFS, MODE_PRIVATE) }
    private lateinit var senderStatus: TextView
    private lateinit var notifStatus: TextView
    private var afterPerms: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        // Bike phone: jump straight into the dashboard next time.
        if (prefs.getString("mode", null) == "dash" && missing(dashPerms()).isEmpty()) startDashboard()
    }

    override fun onResume() {
        super.onResume()
        BikeLink.statusListener = { c, t -> senderStatus.text = (if (c) "🟢 " else "🔴 ") + t }
        senderStatus.text = if (SenderService.instance != null)
            (if (BikeLink.connected) "🟢 " else "🔴 ") + BikeLink.statusText else "Sender not running"
        val enabled = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        notifStatus.text = if (enabled) "✅ Notification access ON" else "⚠️ Notification access OFF"
    }

    override fun onPause() {
        super.onPause()
        BikeLink.statusListener = null
    }

    // ---------- UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun text(s: String, size: Float, color: Int = Color.LTGRAY, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun button(label: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 17f
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(color); cornerRadius = dp(14).toFloat() }
        setOnClickListener { onClick() }
    }

    private fun buildUi(): ScrollView {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
            setBackgroundColor(Color.parseColor("#0B1220"))
        }
        fun add(v: android.view.View, gapTop: Int = 8) =
            col.addView(v, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(gapTop) })

        val blue = Color.parseColor("#1565C0")
        val dark = Color.parseColor("#263042")

        add(text("BikeDash", 34f, Color.WHITE, true), 0)
        add(text("Turn your spare phone into a bike dashboard. First pair the two phones in Bluetooth settings.", 15f))
        add(button("Open Bluetooth settings (pair phones)", dark) {
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        })

        add(text("🏍  On the BIKE phone", 22f, CYAN, true), 28)
        add(text("Shows speed, time, battery, calls and messages from your main phone.", 15f))
        add(button("Start Bike Dashboard", blue) { withPerms(dashPerms()) { startDashboard() } })

        add(text("📱  On the MAIN phone", 22f, CYAN, true), 28)
        add(text("Sends calls & messages to the bike phone over Bluetooth.", 15f))
        add(button("1. Allow permissions", dark) { withPerms(senderPerms()) { toast("Permissions OK") } })
        notifStatus = text("", 14f)
        add(button("2. Allow notification access", dark) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        add(notifStatus, 2)
        add(button("3. Choose bike phone & connect", blue) { withPerms(senderPerms()) { pickDevice() } })
        senderStatus = text("Sender not running", 15f, Color.WHITE)
        add(senderStatus)
        add(button("Send test alert", dark) {
            val s = SenderService.instance
            if (s == null) toast("Start step 3 first")
            else s.send(JSONObject().put("t", "msg").put("app", "BikeDash").put("title", "Test")
                .put("text", "Hello from your main phone 👋"))
        })
        add(button("Stop sender", dark) {
            prefs.edit().remove("mode").apply()
            startService(Intent(this, SenderService::class.java).setAction(SenderService.ACTION_STOP))
            senderStatus.text = "Sender not running"
        })

        return ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0B1220"))
            addView(col)
        }
    }

    // ---------- actions ----------

    private fun startDashboard() {
        prefs.edit().putString("mode", "dash").apply()
        startForegroundService(Intent(this, DashboardService::class.java))
        startActivity(Intent(this, DashboardActivity::class.java))
    }

    @SuppressLint("MissingPermission")
    private fun pickDevice() {
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null || !adapter.isEnabled) { toast("Turn ON Bluetooth first"); return }
        val devices = adapter.bondedDevices.toList()
        if (devices.isEmpty()) {
            toast("No paired phones yet – pair the bike phone first")
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            return
        }
        val names = devices.map { "${it.name ?: "Unknown"}\n${it.address}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Which one is the bike phone?")
            .setItems(names) { _, i ->
                prefs.edit().putString("device", devices[i].address).putString("mode", "sender").apply()
                startForegroundService(Intent(this, SenderService::class.java))
                toast("Connecting to ${devices[i].name ?: "bike phone"}…")
            }
            .show()
    }

    // ---------- permissions ----------

    private fun dashPerms(): List<String> {
        val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 31) p += Manifest.permission.BLUETOOTH_CONNECT
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        return p
    }

    private fun senderPerms(): List<String> {
        val p = mutableListOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (Build.VERSION.SDK_INT >= 31) p += Manifest.permission.BLUETOOTH_CONNECT
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        return p
    }

    private fun missing(perms: List<String>) =
        perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }

    private fun withPerms(perms: List<String>, action: () -> Unit) {
        val m = missing(perms)
        if (m.isEmpty()) { action(); return }
        afterPerms = action
        requestPermissions(m.toTypedArray(), 7)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val action = afterPerms
        afterPerms = null
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            toast("“Nearby devices” permission is needed for Bluetooth")
            return
        }
        action?.invoke()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
