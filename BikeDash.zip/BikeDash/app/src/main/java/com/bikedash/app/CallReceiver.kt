package com.bikedash.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.telephony.TelephonyManager
import org.json.JSONObject

/** MAIN phone: watches incoming calls and forwards caller name/number. */
class CallReceiver : BroadcastReceiver() {

    companion object {
        @Volatile private var ringSent = false
        @Volatile private var lastName = ""
        @Volatile private var lastNumber = ""
        @Volatile private var lastState = ""
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        if (SenderService.instance == null) return
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        @Suppress("DEPRECATION")
        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        lastState = state

        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                if (number != null) {
                    if (ringSent && number == lastNumber) return
                    lastNumber = number
                    lastName = contactName(ctx, number) ?: ""
                    ringSent = true
                    send("ringing")
                } else if (!ringSent) {
                    // Android sends this twice; the number usually comes in the 2nd one.
                    Handler(Looper.getMainLooper()).postDelayed({
                        if (!ringSent && lastState == TelephonyManager.EXTRA_STATE_RINGING) {
                            ringSent = true
                            send("ringing")
                        }
                    }, 1500)
                }
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> send("active")
            TelephonyManager.EXTRA_STATE_IDLE -> {
                send("end")
                ringSent = false
                lastName = ""
                lastNumber = ""
            }
        }
    }

    private fun send(state: String) {
        SenderService.instance?.send(
            JSONObject().put("t", "call").put("state", state)
                .put("name", lastName).put("number", lastNumber)
        )
    }

    private fun contactName(ctx: Context, number: String): String? = try {
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
        ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    } catch (e: Exception) {
        null
    }
}
