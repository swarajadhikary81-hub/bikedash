package com.bikedash.app

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.util.UUID

/** Shared constants + a tiny in-app event bus between services and screens. */
object BikeLink {
    val UUID_SPP: UUID = UUID.fromString("7f3c2a9e-5b1d-4e8a-9c6f-2d4b8e1a0c55")
    const val NAME = "BikeDash"
    const val PREFS = "bikedash"

    private val main = Handler(Looper.getMainLooper())

    var listener: ((JSONObject) -> Unit)? = null
    var statusListener: ((Boolean, String) -> Unit)? = null

    @Volatile var connected = false
    @Volatile var statusText = "Waiting for main phone…"
    @Volatile var lastMsg: JSONObject? = null
    @Volatile var lastCall: JSONObject? = null
    @Volatile var mainBattery = -1

    fun emit(o: JSONObject) {
        main.post { listener?.invoke(o) }
    }

    fun setStatus(isConnected: Boolean, text: String) {
        connected = isConnected
        statusText = text
        main.post { statusListener?.invoke(isConnected, text) }
    }
}
