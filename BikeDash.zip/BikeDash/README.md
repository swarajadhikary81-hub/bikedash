# BikeDash – turn a spare phone into a bike dashboard

Two phones run the same app:

* **Bike phone** (the spare one with SIM internet, mounted on the bike): shows a large dashboard with speed (GPS), time, both batteries, the latest message, and a full-screen caller card with **Answer** and **Reject** buttons. It also reads alerts aloud (handy with a helmet headset) and keeps working as pop-ups while Google Maps is open.
* **Main phone** (in your pocket): sends incoming calls (with the contact name), WhatsApp, SMS and other notifications to the bike phone over Bluetooth.

Both phones need Android 8.0 or newer. iPhone is not supported.

## Get the APK (no Android Studio needed)
1. Create a free account at github.com and make a new repository (for example `bikedash`).
2. Choose **Add file → Upload files**, then drag in everything inside this folder, including the hidden `.github` folder. Then commit.
   - The web uploader can skip hidden folders. If `.github/workflows/build-apk.yml` is missing afterwards, use **Add file → Create new file**, name it `.github/workflows/build-apk.yml`, and paste in its contents.
3. Open the **Actions** tab and wait about 5 minutes for "Build APK" to show a green tick.
4. Open the finished run and download **BikeDash-apk** under Artifacts. Unzip it to get `app-debug.apk`.
5. Install that APK on both phones. You'll need to allow "Install unknown apps".

**Or with Android Studio:** open this folder, then choose Build → Build APK(s).

## Setup
1. Pair the two phones once in Android Bluetooth settings.
2. **Bike phone:** open BikeDash, tap **Start Bike Dashboard**, and allow location, nearby devices and notifications.
3. **Main phone:** open BikeDash and do steps 1 → 2 → 3:
   1. Allow permissions (phone, call log, contacts, nearby devices).
   2. Allow notification access and switch BikeDash ON.
   3. Choose the bike phone from the list. The status should turn 🟢 Connected.
4. Tap **Send test alert**. It should appear on the bike phone.

Both sides reconnect on their own if Bluetooth drops, and they start again after a reboot.

## Tips
* Turn off battery optimisation for BikeDash on both phones (Settings → Apps → BikeDash → Battery → Unrestricted). This matters a lot on Xiaomi, Realme, Oppo and Vivo phones.
* The 🧭 Maps button opens Google Maps. Calls and messages still pop up over the map.
* To answer from the bike, the call audio plays on the **main phone**, so pair your helmet headset with the main phone.

## Customise
* Colours, layout and button labels: `DashboardActivity.kt`
* Apps to mute: the `blocked` list in `NotifListener.kt`
* What the voice says: `speak(...)` calls in `DashboardService.kt`
